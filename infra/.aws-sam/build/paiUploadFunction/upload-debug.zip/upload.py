import json
import base64
import os
import uuid
import io
import requests
from common.storage import upload_pdf_to_s3, store_metadata
import boto3
import numpy as np
from PyPDF2 import PdfReader
from decimal import Decimal  # <-- Add this import

def extract_text_from_pdf(file_content):
    pdf_stream = io.BytesIO(file_content)
    reader = PdfReader(pdf_stream)
    text = "\n".join([page.extract_text() or "" for page in reader.pages])
    return text

def chunk_text(text, chunk_size=500):
    return [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]

def get_embeddings(chunks):
    # Generate embeddings using a consistent text-to-vector approach
    # This ensures compatibility between upload and query functions
    import hashlib
    
    embeddings = []
    for chunk in chunks:
        # Use text content to generate a deterministic embedding
        text_bytes = chunk.encode('utf-8')
        hash_obj = hashlib.sha256(text_bytes)
        
        # Generate 768 dimensions (common embedding size)
        embedding = []
        seed = hash_obj.hexdigest()
        
        for i in range(768):
            # Use different parts of the hash to generate different values
            char_idx = i % len(seed)
            value = ord(seed[char_idx]) / 255.0  # Normalize to 0-1
            # Add some variation based on position
            value = (value + (i * 0.001)) % 1.0
            embedding.append(value)
        
        embeddings.append(embedding)
    
    return np.array(embeddings, dtype=np.float32)

def lambda_handler(event, context):
    try:
        # Handle CORS preflight requests first (before any other processing)
        http_method = event.get('httpMethod') or event.get('requestContext', {}).get('http', {}).get('method')
        
        if http_method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-filename',
                    'Content-Type': 'application/json'
                },
                'body': json.dumps({'message': 'CORS preflight success'})
            }

        # Check for Cognito identity
        user_id = event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {}).get('sub', 'anonymous')
        
        # Get filename and auth from query parameters
        query_params = event.get('queryStringParameters') or {}
        filename = query_params.get('filename', 'upload.pdf')
        auth_token = query_params.get('auth', '')
        
        # Handle request body
        body = event.get('body')
        if not body:
            raise ValueError('No file content provided')
            
        if event.get('isBase64Encoded'):
            file_content = base64.b64decode(body)
        else:
            if isinstance(body, str):
                file_content = body.encode('latin-1')
            else:
                file_content = body
        doc_id = str(uuid.uuid4())
        s3_key = upload_pdf_to_s3(file_content, filename, user_id)
        text = extract_text_from_pdf(file_content)
        chunks = chunk_text(text)
        embeddings = get_embeddings(chunks)
        # Store all data in DynamoDB in a single operation
        table = os.environ.get('DYNAMODB_TABLE', 'pai-embeddings-metadata')
        dynamodb = boto3.resource('dynamodb')
        # Convert all floats in embeddings to Decimal
        embeddings_decimal = [[Decimal(str(x)) for x in emb] for emb in embeddings.tolist()]
        
        # Store everything in one put_item operation
        print(f"Attempting to store document with doc_id: {doc_id}")
        print(f"Table name: {table}")
        print(f"Number of chunks: {len(chunks)}")
        print(f"Number of embeddings: {len(embeddings_decimal)}")
        
        try:
            response = dynamodb.Table(table).put_item(
                Item={
                    'doc_id': doc_id,
                    'user_id': user_id,
                    'filename': filename,
                    's3_key': s3_key,
                    'chunks': chunks,
                    'embeddings': embeddings_decimal
                }
            )
            print(f"DynamoDB put_item successful: {response}")
        except Exception as db_error:
            print(f"DynamoDB error: {str(db_error)}")
            raise db_error
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-filename'
            },
            'body': json.dumps({'doc_id': doc_id, 's3_key': s3_key})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }
